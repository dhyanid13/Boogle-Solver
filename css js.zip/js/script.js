	var currentWord = "";
    var hour = "00";
    var min = "00";
    var sec = "00"; 
	var lastRow, lastCol;
	var englishWords;
	var allWords;
	var playerWords;
	var lastword="";
	var flag = {};
	var boardMapStr;
	var boggleSize;
	var gameOver = false;
	var start_game=false;
    var glevel=false;
	var timerinterval="";
		var englishWords = [];
			var gameOver = false;
var STANDARD_CUBES = [
	"AAEEGN", "ABBJOO", "ACHOPS", "AFFKPS",
	"AOOTTW", "CIMOTU", "DEILRX", "DELRVY",
	"DISTTY", "EEGHNW", "EEINSU", "EHRTVW",
	"EIOSST", "ELRTTY", "HIMNQU", "HLNNRZ"
];
var BIG_BOGGLE_CUBES = [
	"AAAFRS", "AAEEEE", "AAFIRS", "ADENNN", "AEEEEM",
	"AEEGMU", "AEGMNN", "AFIRSY", "BJKQXZ", "CCNSTW",
	"CEIILT", "CEILPT", "CEIPST", "DDLNOR", "DDHNOT",
	"DHHLOR", "DHLNOR", "EIIITT", "EMOTTT", "ENSSSU",
	"FIPRSY", "GORRVW", "HIPRRY", "NOOTUW", "OOOTTU"
];
function binarySearch(items, value) {
	var startIndex = 0,
		stopIndex = items.length - 1,
		middle = Math.floor((stopIndex + startIndex) / 2);
	while (items[middle] != value && startIndex < stopIndex) {
		if (value < items[middle]) {
			stopIndex = middle - 1;
		} else if (value > items[middle]) {
			startIndex = middle + 1;
		}
		middle = Math.floor((stopIndex + startIndex) / 2);
	}
	return (items[middle] != value) ? -1 : middle;
}

function binarySearchPrefix(items, value) {
	var startIndex = 0,
		stopIndex = items.length - 1,
		middle = Math.floor((stopIndex + startIndex) / 2);
	while (items[middle].substring(0, value.length) != value && startIndex < stopIndex) {
		if (value < items[middle].substring(0, value.length)) {
			stopIndex = middle - 1;
		} else if (value > items[middle].substring(0, value.length)) {
			startIndex = middle + 1;
		}
		middle = Math.floor(Math.abs(stopIndex + startIndex) / 2);
	}
	return items[middle].substring(0, value.length) == value;
}

function binaryInsert(items, value) {
	var startIndex = 0,
		stopIndex = items.length - 1,
		middle = Math.floor((stopIndex + startIndex) / 2);
	while (items[middle] != value && startIndex < stopIndex) {
		if (value < items[middle]) {
			stopIndex = middle - 1;
		} else if (value > items[middle]) {
			startIndex = middle + 1;
		}
		middle = Math.floor(Math.abs(stopIndex + startIndex) / 2);
	}
	if (items[middle] <= value)
		middle += 1;
	items.splice(middle, 0, value);
}
	function recordWord(word, isComputer) {
		if (word.length < 4) return false;
		word = word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
		var point = word.length - 3;
		var wordCard = $('<div class="wordCard"><div class="word"></div><div class="point"></div></div>');
		wordCard.find('.word').text(word);
		if (isComputer=="error") {
		wordCard.find('.point').text('-' + point);
		}
		else
		 {
			wordCard.find('.point').text('+' + point);
		 }
		
		if (isComputer=="error") {
			$('#errorboard .word_card_container').prepend(wordCard);
			$('#errorscore').text(parseInt($('#errorscore').text()) + point);
			$('#errorboard .word_card_container').scrollTop(10000000);
		} else if (isComputer=="correct") {
			$('#correctboard .word_card_container').prepend(wordCard);
			$('#score').text(parseInt($('#score').text()) + point);
			wordCard.hide().slideDown(500, function() {
				$('#correctboard .word_card_container').scrollTop(10000000);
			});
		}
		else if (isComputer=="answers") {
			$('#answerboard').css('display','table-cell');
            $('.game_container').addClass("game_container_with_answer");
			$('#answerboard .word_card_container').append(wordCard);
		
			$('#answerboard .word_card_container').scrollTop(10000000);
		}
	}

	function findAllWords(word, passedflag, x, y) {
		var newFlag = $.extend({}, passedflag);
		newFlag[x * boggleSize + y] = true;
		word += boardMapStr[x * boggleSize + y];
		if (word.length > 3 && trieSearch(englishWords, word.toLowerCase()) && !trieSearch(allWords, word)) {
			trieInsert(allWords, word);
		}
		for (var i = x - 1; i <= x + 1; i++)
			for (var j = y - 1; j <= y + 1; j++)
				if (i >= 0 && i < boggleSize && j >= 0 && j < boggleSize && newFlag[i * boggleSize + j] != true && trieSearch(englishWords, (word + boardMapStr[i * boggleSize + j]).toLowerCase(), true)) {
					findAllWords(word, newFlag, i, j);
				}
	}
function trieSearch(trie, word, prefixOnly) {
	var curr = trie;
	for (var i = 0; i < word.length; i++) {
		if (typeof curr[word[i]] != 'object') return false;
		curr = curr[word[i]];
	}
	if (prefixOnly) return true;
	return curr['$'] == 1;
}

function trieInsert(trie, word) {
	var curr = trie;
	for (var j = 0; j < word.length; j++) {
		var letter = word[j];
		if (typeof curr[letter] == 'undefined') {
			curr[letter] = {};
		}
		curr = curr[letter];
	}
	curr["$"] = 1;
}

function trieIterator(trie, callback, prefix) {
	if (!prefix) prefix = "";
	Object.keys(trie).forEach(function(key) {
  		if (key == '$') {
			callback(prefix);
		} else {
			trieIterator(trie[key], callback, prefix + key);
		}
	});
}
function count() {
        if(sec <= 0 &&min > 0) {
            sec = 59;
            min -= 1;
        }
        else if(min <= 0 &&sec <= 0) {
            min = 0;
            sec = 0;
        }
        else {
            sec -= 1;
        }
        if(min <= 0 &&hour > 0) {
            min = 59;
            hour -= 1;
        }
    var pattern = /^[0-9]{1}$/;
    sec = (pattern.test(sec) == true) ? '0'+sec : sec;
    min = (pattern.test(min) == true) ? '0'+min : min;
    hour = (pattern.test(hour) == true) ? '0'+hour : hour;
    $("#time").html(min+":"+sec);
    if (min=='00' &&sec=='00') {
		timeout();
		
		}
    
}
function start_timer() {
  timerinterval=setInterval(count, 1000);
  
}
function clear_timer() {
	  hour = "00";
    min = "00";
    sec = "00";
   clearInterval(timerinterval);
}
function timeout() {
    clearInterval(timerinterval);
	 if (confirm("Oops !! Timeout. If you want to end game, click OK  \n If you wish to continue playing, Click Cancel"))
	 {
	   currentWord="";
		$( "#mainBtn" ).trigger( "click" );
	   	
	 }
	 else
	 {
		$('#timer_img').attr('src','./timer-stop.png');
	 }
	
}
	function loadBoggle(big)
	{
		start_game=true;
			  hour = "00";
    min = "00";
    sec = "00";
		$('#answerboard').css('display','none');
		playerWords = {};
		allWords = {};
		$('#gameCube .letterBox').remove();
		$('#gameCube .letterBox').remove();
		$('.wordCard').slideUp(500, function() {
			$(this).remove();
		});
		$('#errorscore').text(0);
		$('#score').text(0);
		boardMapStr = "";
		var boardCube;
		if (big) {
			boggleSize = 5;
			min="05";
			$('#gameCube').attr('board', 'big');
			$('#answerboard').attr('board', 'big');
			
			boardCube = BIG_BOGGLE_CUBES;
		} else {
			boggleSize = 4;
			min="03";
			$('#gameCube').attr('board', 'standard');
			$('#answerboard').attr('board', 'standard');
			boardCube = STANDARD_CUBES;
		}
        
		for (var i = 0; i < boggleSize * boggleSize; i++) {
			var randIndex = Math.floor((Math.random() * boggleSize * boggleSize));
			var tmp = boardCube[randIndex];
			boardCube[randIndex] = boardCube[i];
			boardCube[i] = tmp;
		}
		for (var i = 0; i < boggleSize * boggleSize; i++) {
			boardMapStr += boardCube[i][Math.floor((Math.random() * 6))];
		}
		
		for (var i = 0; i < boggleSize; i++)
			for (var j = 0; j < boggleSize; j++) {
				
				var letterBoxDiv = $('<div class="letterBox"></div>').attr({
					"row": i,
					"col": j
				}).data("pos", {
					"row": i,
					"col": j
				}).text(boardMapStr[i * boggleSize + j]).click(function() {
					
					var pos = $(this).data('pos');
					if ($(this).hasClass('selected'))
					{
						
						if (lastword==boardMapStr[pos.row * boggleSize + pos.col]) {
                            $(this).removeClass('selected')	
					  remove_letter(pos.row, pos.col)
                        }
						else
						{
							return false;
						}
					  
					}
					else
					{
						
					
					letterOnClick(pos.row, pos.col);
					}
				})
                
				$('#gameCube1').append(letterBoxDiv);
			}
		$('#mainBtn').text("End Game").show();
		//updateMonitor("Click On Letters Successively");
		 $('#mainBtn').css('display','inline-block');
        $('#rotate').css('display','inline-block');
        $('.info_line').addClass("info_line_width");
        start_timer();
	}
		function monitorDisplay(str) {
		$('#infoLine').text($('#infoLine').text() + str[0]);
		if (str.length > 1) {
			setTimeout(function() {
				monitorDisplay(str.substring(1));
			}, 10);
		}
	}
    function remove_letter(row,col)
	{
      currentWord=currentWord.substring(0, currentWord.length - 1);
	  lastword=currentWord.substring(currentWord.length - 1, currentWord.length);
	  	lastRow = row;
		lastCol = col;
		 delete flag[row * boggleSize + col];
	  updateMonitor();
    }
	function letterOnClick(row, col) {
		
		
		if (gameOver)
			return false;
		
		if (currentWord.length > 0 && (Math.abs(row - lastRow) > 1 || Math.abs(col - lastCol) > 1))
		{
            console.log("1");
			console.log("return")
			return false;
		}
		
		if (flag[row * boggleSize + col])
		{
		    console.log("2");
			return false;
		}
		
		currentWord += boardMapStr[row * boggleSize + col];
		flag[row * boggleSize + col] = true;
		lastword=boardMapStr[row * boggleSize + col];
		$(".letterBox[row=\"" + row + "\"][col=\"" + col + "\"]").addClass("selected");
		lastRow = row;
		lastCol = col;
		updateMonitor();
		$('#mainBtn').text("Add Word");
	}
		function updateMonitor(str) {
		if (typeof str !== "string") {
			$('#infoLine').text(currentWord);
		} else {
			$('#infoLine').text('');
			monitorDisplay(str );
		}
	}
	
	function gameReady() {
		$('#msg').html("");
		
		$('#cover .waiting').fadeOut(500, function() {
			$('.startButton').css('opacity', 1);
		});
		$('#standardStardButton').click(function() {
			$('#cover').css('position','absolute');
			loadBoggle();
            glevel=false;
			$('#cover').fadeOut(500);
		});
		$('#bigStardButton').click(function() {
			$('#cover').css('position','absolute');
			loadBoggle(true);
            glevel=true;
			$('#cover').fadeOut(500);
		});
		updateMonitor('Welcome To Boggle');
	}
	function rotate() {
        if (confirm("Are you sure want to refresh this board")) {
                //code
				 clear_timer(); 
         currentWord = "";
			flag = {};
		$('#timer_img').attr('src','./timer.png');	
        $('.game_container').removeClass("game_container_with_answer");
        $('#rotate').css('display','none')
       gameReady();
	   loadBoggle(glevel);
        }
    }
$(document).ready(function() {
	
	$.ajax({
  xhrFields: {
onprogress: function (e) {
if (e.lengthComputable) {
$load_cnt=Math.floor(e.loaded / e.total * 100) + '%';
$load_cnt_1=Math.floor(e.loaded / e.total * 100);
$('#load_cnt').html($load_cnt);
$('#cicle_loader').removeClass();
$('#cicle_loader').addClass("c100 p"+$load_cnt_1+" small ");

}
}
},
  type: 'GET',
  url: "englishWords.json",
  data: {},
  dataType: 'json',
  success: function(data){
	
    englishWords = data;
		gameReady();
  }
});

	/*	$.get('englishWords.json', function(data) {
		englishWords = data;
		gameReady();
	}, 'json');
	*/	
	$('#timer-div').click(function() {
		if (start_game) {
            //code
       
		var srcc=$('#timer_img').attr('src');
	
		if (srcc=="./timer.png") {
           clear_timer();
		   $('#timer_img').attr('src','./timer-stop.png');
        }
		else
		{
			$('#timer_img').attr('src','./timer.png');
		start_timer();
		}
		}
	});	
	$('#mainBtn').click(function() {
		if (gameOver) {
			gameOver = false;
			 clear_timer();
			 			  hour = "00";
    min = "00";
    sec = "00";
	        		$('#timer_img').attr('src','./timer.png');	

			$('.game_container').removeClass("game_container_with_answer");
		  $('#update_score').css('display','none');
			$('#answerboard').css('display','none');
			updateMonitor('Welcome To Boggle');
			$('#cover').css('position','absolute');
			 $('#cover').css('z-index','1');
			
			if (boggleSize==5) {
           
			$('#cover').css('top','7%');    //code
			 $('.intro').css('margin-top','25%');    //code
			
            }
			else
			{
				
			$('#cover').css('top','-3%');
			 $('.intro').css('margin-top','15%');    //code
			
			}
			$("#cover").fadeIn(500);
			$(this).fadeOut(500);
			 $('#rotate').css('display','none');
			return;
		}
		if (currentWord.length > 0) {
			if (currentWord.length < 4) {
				updateMonitor("'" + currentWord + "' is too short");
			} else if (!trieSearch(englishWords, currentWord.toLowerCase())) {
				recordWord(currentWord,"error");
				updateMonitor("'" + currentWord + "' is not a word");
			} else if (trieSearch(playerWords, currentWord)) {
				updateMonitor("You already have '" + currentWord + "'");
			} else {
				recordWord(currentWord,"correct");
				trieInsert(playerWords, currentWord);
				updateMonitor("You find '" + currentWord + "'");
			}
			currentWord = "";
			flag = {};
			$('#mainBtn').text("End Game");
			$('.letterBox.selected').removeClass('selected');
		} else {
            if (confirm("Are you sure want to end this game")) {
                //code
           clear_timer(); 
			for (var i = 0; i < boggleSize; i++)
				for (var j = 0; j < boggleSize; j++) {
					var passedflag = {};
					findAllWords("", passedflag, i, j);
				}
			trieIterator(allWords, function(word) {
				if (!trieSearch(playerWords, word)) {
					recordWord(word, "answers");
				}
			});
			$('#answer_count').text($('#answer_words > div').size());
			var myscore = parseInt($('#score').text()),
				errorscore = parseInt($('#errorscore').text());
			var score=myscore-errorscore;
		
		
				updateMonitor("Your Score is  " + score );
		
			gameOver = true;
			start_game=false;
			$('#mainBtn').text('Play Again');
            }
		}
	});
		});